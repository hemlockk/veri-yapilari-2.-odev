/**
* @file G191210012
* @description veri.txt dosyasını okuyup her bir firma için iç ağaçta bir node oluşturuyor ve her bir elemanı eşleştiğin firma ağacının gösterdiği dış ağaca ekliyor
* @course 2. öğretim B grubu
* @assignment 2. ödev
* @date Kodu 27.12.2020
* @author Ali Yusuf Akbay ali.yusuf01@hotmail.com
*/
#ifndef AVL_HPP
#define AVL_HPP
#include <iostream>
#include "node.hpp"
using namespace std;
class AVL {
private:
    node* root;
    void makeEmpty(node*);
    node* insert(int, string, node*);
     node* singleRightRotate(node*&);
	 node* singleLeftRotate(node*&);
	 node* doubleLeftRotate(node*&);
	 node* doubleRightRotate(node*&);
	 node* findMin(node*);
	 node* findMax(node*);
	 node* remove(int, node*);
	 int height(node*);
	 node* search(string, node*);
	 int getBalance(node*);
	 void postOrder(node*);
public:
    AVL();
    void insert(int,string);
	void remove(int);
	void display(string);
    void display();
    node* search(string);
    void insert(int,string,string);
};
#endif

