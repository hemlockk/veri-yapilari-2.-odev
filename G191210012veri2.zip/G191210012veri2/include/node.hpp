#ifndef NODE_HPP
#define NODE_HPP
#include <iostream>
using namespace std;
class node {
public:
    	int intData;
        string stringData;
        node* left;
        node* right;
        node* treePointer;
        int height;
};
#endif