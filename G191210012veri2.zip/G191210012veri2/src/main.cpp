/**
* @file G191210012
* @description veri.txt dosyasını okuyup her bir firma için iç ağaçta bir node oluşturuyor ve her bir elemanı eşleştiğin firma ağacının gösterdiği dış ağaca ekliyor
* @course 2. öğretim B grubu
* @assignment 2. ödev
* @date Kodu 27.12.2020
* @author Ali Yusuf Akbay ali.yusuf01@hotmail.com
*/
#include <iostream>
#include <fstream>
#include <string>
#include "AVL.hpp"
using namespace std;
int main()
{
    AVL* t = new AVL;
    ifstream MyFile("Veri.txt");
    string myText;
    string employeName;
    int date = 0;
    string companyName;
	string* uniquecompanyName = new string[1000];
	int uniquecompanyCounter = 0;
    int theOrder = 0;
    while (getline(MyFile, myText)) {
        myText = myText + '#';
        int traker = 0;
        int tracer = 0;
        while (tracer != myText.length()) {
            if (myText.at(tracer) != '#') {
                tracer++;
            }
            else {
                if (tracer != traker) {
                    if (theOrder == 0) {
                        companyName = myText.substr(traker, tracer - traker);
						if(t->search(companyName) == NULL){
							uniquecompanyName[uniquecompanyCounter] = companyName;
							uniquecompanyCounter++;
						}
                    }
                    if (theOrder == 1) {
                        employeName = myText.substr(traker, tracer - traker);
                    }
                    if (theOrder == 2) {
                        date = stoi(myText.substr(traker, tracer - traker));
                    }
                    tracer--;
                    theOrder++;
                }
                tracer++;
                traker = tracer;
            }
        }
        
        t->insert(date, employeName, companyName);
        theOrder = 0;
    }
	cout << "sirket isimleri ve eleman sayilari: ";
    t->display();
	cout << endl;
	for (int i = 0; i < uniquecompanyCounter; i++){
				cout << "sirket adi: " << uniquecompanyName[i];
				cout << endl;
				cout << "elemanlari: ";
                t->display(uniquecompanyName[i]);
				cout << endl;
	}
	delete t;
	MyFile.close();
    return 0;
}